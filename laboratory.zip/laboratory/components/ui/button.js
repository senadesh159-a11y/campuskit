export function createButton({
    text = "Button",
    variant = "primary",
    onClick = () => {},
    disabled = false
} = {}) {
    const button = document.createElement("button");

    button.type = "button";
    button.textContent = text;
    button.className = `lab-button lab-button-${variant}`;
    button.disabled = disabled;

    button.addEventListener("click", onClick);

    return button;
}