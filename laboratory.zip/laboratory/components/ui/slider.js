export function createSlider({
    label = "Adjust Value",
    min = 0,
    max = 100,
    step = 1,
    value = 50,
    unit = "",
    onChange = () => {}
} = {}) {
    const wrapper = document.createElement("div");
    wrapper.className = "lab-slider-wrapper";

    const heading = document.createElement("label");
    heading.className = "lab-slider-label";

    const valueDisplay = document.createElement("span");

    const slider = document.createElement("input");
    slider.type = "range";
    slider.min = min;
    slider.max = max;
    slider.step = step;
    slider.value = Math.min(max, Math.max(min, value));

    function updateDisplay() {
        valueDisplay.textContent = `${slider.value} ${unit}`.trim();
    }

    heading.textContent = label;
    heading.appendChild(valueDisplay);

    slider.addEventListener("input", () => {
        updateDisplay();
        onChange(Number(slider.value));
    });

    updateDisplay();

    wrapper.append(heading, slider);

    return {
        element: wrapper,
        slider,

        getValue() {
            return Number(slider.value);
        },

        setValue(newValue) {
            slider.value = Math.min(max, Math.max(min, newValue));
            updateDisplay();
        },

        setDisabled(disabled) {
            slider.disabled = Boolean(disabled);
        }
    };
}