export function createGraph({
    title = "Experiment Graph",
    xLabel = "X Axis",
    yLabel = "Y Axis",
    data = []
} = {}) {
    const container = document.createElement("section");
    container.className = "lab-graph";

    const heading = document.createElement("h3");
    heading.textContent = title;

    const canvas = document.createElement("canvas");
    canvas.setAttribute("role", "img");
    canvas.setAttribute(
        "aria-label",
        `${title}: graph of ${yLabel} against ${xLabel}`
    );

    container.append(heading, canvas);

    const context = canvas.getContext("2d");

    let graphData = [...data];

    function draw() {
        const width = canvas.clientWidth || 500;
        const height = 300;
        const ratio = Math.min(window.devicePixelRatio || 1, 2);

        canvas.width = width * ratio;
        canvas.height = height * ratio;

        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        context.clearRect(0, 0, width, height);

        const points = graphData.filter(
            point =>
                Number.isFinite(point.x) &&
                Number.isFinite(point.y)
        );

        if (points.length === 0) {
            context.fillText("No graph data available", 20, 40);
            return;
        }

        const padding = 45;

        const minX = Math.min(...points.map(p => p.x));
        const maxX = Math.max(...points.map(p => p.x));
        const minY = Math.min(...points.map(p => p.y));
        const maxY = Math.max(...points.map(p => p.y));

        const rangeX = maxX - minX || 1;
        const rangeY = maxY - minY || 1;

        const plotWidth = width - padding * 2;
        const plotHeight = height - padding * 2;

        const toCanvasX = x =>
            padding + ((x - minX) / rangeX) * plotWidth;

        const toCanvasY = y =>
            height - padding - ((y - minY) / rangeY) * plotHeight;

        // Draw axes
        context.strokeStyle = "#888";
        context.lineWidth = 1;

        context.beginPath();
        context.moveTo(padding, padding);
        context.lineTo(padding, height - padding);
        context.lineTo(width - padding, height - padding);
        context.stroke();

        // Draw data line
        context.strokeStyle = "#a3e635";
        context.lineWidth = 2;

        context.beginPath();

        points.forEach((point, index) => {
            const x = toCanvasX(point.x);
            const y = toCanvasY(point.y);

            if (index === 0) {
                context.moveTo(x, y);
            } else {
                context.lineTo(x, y);
            }
        });

        context.stroke();

        // Draw data points
        context.fillStyle = "#a3e635";

        points.forEach(point => {
            context.beginPath();
            context.arc(
                toCanvasX(point.x),
                toCanvasY(point.y),
                4,
                0,
                Math.PI * 2
            );
            context.fill();
        });

        // Axis labels
        context.fillStyle = "#ffffff";
        context.font = "12px sans-serif";
        context.textAlign = "center";

        context.fillText(
            xLabel,
            width / 2,
            height - 8
        );

        context.save();
        context.translate(14, height / 2);
        context.rotate(-Math.PI / 2);
        context.fillText(yLabel, 0, 0);
        context.restore();
    }

    function setData(newData) {
        graphData = [...newData];
        draw();
    }

    const resizeObserver = new ResizeObserver(draw);
    resizeObserver.observe(container);

    return {
        element: container,
        canvas,
        setData,
        redraw: draw,

        dispose() {
            resizeObserver.disconnect();
            container.remove();
        }
    };
}