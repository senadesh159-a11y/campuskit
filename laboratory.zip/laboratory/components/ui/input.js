export function createInput({
    type = "text",
    placeholder = "",
    value = "",
    label = "",
    min,
    max,
    step,
    onChange = () => {}
} = {}) {
    const wrapper = document.createElement("div");
    wrapper.className = "lab-input-wrapper";

    if (label) {
        const inputLabel = document.createElement("label");
        inputLabel.textContent = label;
        wrapper.appendChild(inputLabel);
    }

    const input = document.createElement("input");

    input.type = type;
    input.placeholder = placeholder;
    input.value = value;

    if (min !== undefined) input.min = min;
    if (max !== undefined) input.max = max;
    if (step !== undefined) input.step = step;

    input.addEventListener("input", () => {
        onChange(input.value, input);
    });

    wrapper.appendChild(input);

    return {
        element: wrapper,
        input,

        getValue() {
            return input.value;
        },

        setValue(newValue) {
            input.value = newValue;
        },

        setDisabled(disabled) {
            input.disabled = Boolean(disabled);
        }
    };
}