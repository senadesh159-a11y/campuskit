export function createControlPanel({
    title = "Experiment Controls",
    controls = []
} = {}) {
    const panel = document.createElement("section");
    panel.className = "lab-control-panel";

    const heading = document.createElement("h3");
    heading.textContent = title;

    const content = document.createElement("div");
    content.className = "lab-control-panel-content";

    panel.append(heading, content);

    controls.forEach(control => {
        if (control instanceof HTMLElement) {
            content.appendChild(control);
        }
    });

    return {
        element: panel,

        addControl(control) {
            if (!(control instanceof HTMLElement)) {
                throw new Error("Control must be an HTML element.");
            }

            content.appendChild(control);
        },

        clear() {
            content.replaceChildren();
        }
    };
}