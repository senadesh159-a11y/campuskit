export function createInstructions({
    title = "Experiment Instructions",
    steps = []
} = {}) {
    const container = document.createElement("section");
    container.className = "lab-instructions";

    const heading = document.createElement("h3");
    heading.textContent = title;

    const list = document.createElement("ol");

    steps.forEach(step => {
        const item = document.createElement("li");
        item.textContent = step;
        list.appendChild(item);
    });

    container.append(heading, list);

    return {
        element: container,

        setSteps(newSteps) {
            list.replaceChildren();

            newSteps.forEach(step => {
                const item = document.createElement("li");
                item.textContent = step;
                list.appendChild(item);
            });
        }
    };
}