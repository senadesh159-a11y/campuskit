export function showLoading(container, message = "Loading laboratory...") {
    if (!container) {
        throw new Error("Loading container not found.");
    }

    const overlay = document.createElement("div");

    overlay.className = "lab-loading";
    overlay.setAttribute("role", "status");
    overlay.setAttribute("aria-live", "polite");

    const spinner = document.createElement("div");
    spinner.className = "lab-loading-spinner";

    const text = document.createElement("p");
    text.textContent = message;

    overlay.append(spinner, text);
    container.appendChild(overlay);

    return {
        update(newMessage) {
            text.textContent = newMessage;
        },

        hide() {
            overlay.remove();
        }
    };
}