export function showToast(
    message,
    type = "info",
    duration = 3000
) {
    const toast = document.createElement("div");

    toast.className = `lab-toast lab-toast-${type}`;
    toast.textContent = message;

    toast.setAttribute("role", "status");
    toast.setAttribute("aria-live", "polite");

    document.body.appendChild(toast);

    const timeout = window.setTimeout(() => {
        toast.remove();
    }, duration);

    return {
        element: toast,

        dismiss() {
            window.clearTimeout(timeout);
            toast.remove();
        }
    };
}