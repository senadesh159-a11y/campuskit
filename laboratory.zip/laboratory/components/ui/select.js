export function createSelect({
    label = "Select Option",
    options = [],
    value = "",
    onChange = () => {}
} = {}) {
    const wrapper = document.createElement("div");
    wrapper.className = "lab-select-wrapper";

    const selectLabel = document.createElement("label");
    selectLabel.textContent = label;

    const select = document.createElement("select");
    select.className = "lab-select";

    options.forEach(option => {
        const item = document.createElement("option");

        if (typeof option === "string") {
            item.value = option;
            item.textContent = option;
        } else {
            item.value = option.value;
            item.textContent = option.label;
        }

        select.appendChild(item);
    });

    select.value = value;

    select.addEventListener("change", () => {
        onChange(select.value);
    });

    wrapper.append(selectLabel, select);

    return {
        element: wrapper,
        select,

        getValue() {
            return select.value;
        },

        setValue(newValue) {
            select.value = newValue;
        },

        setDisabled(disabled) {
            select.disabled = Boolean(disabled);
        }
    };
}