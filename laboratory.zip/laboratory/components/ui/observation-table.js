export function createObservationTable({
    title = "Observation Table",
    columns = [],
    rows = []
} = {}) {
    const container = document.createElement("section");
    container.className = "lab-observation-table";

    const heading = document.createElement("h3");
    heading.textContent = title;

    const table = document.createElement("table");
    const thead = document.createElement("thead");
    const tbody = document.createElement("tbody");

    function renderColumns() {
        const headerRow = document.createElement("tr");

        columns.forEach(column => {
            const th = document.createElement("th");
            th.textContent = column.label;
            headerRow.appendChild(th);
        });

        thead.replaceChildren(headerRow);
    }

    function renderRows() {
        tbody.replaceChildren();

        rows.forEach(row => {
            const tr = document.createElement("tr");

            columns.forEach(column => {
                const td = document.createElement("td");
                td.textContent = row[column.key] ?? "—";
                tr.appendChild(td);
            });

            tbody.appendChild(tr);
        });
    }

    function setRows(newRows) {
        rows = [...newRows];
        renderRows();
    }

    renderColumns();
    renderRows();

    table.append(thead, tbody);
    container.append(heading, table);

    return {
        element: container,
        table,
        setRows,

        addRow(row) {
            rows.push(row);
            renderRows();
        },

        clear() {
            rows = [];
            renderRows();
        },

        getRows() {
            return [...rows];
        }
    };
}