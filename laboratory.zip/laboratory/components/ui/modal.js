export function createModal({
    title = "Laboratory",
    content = ""
} = {}) {
    const overlay = document.createElement("div");
    overlay.className = "lab-modal-overlay";

    const modal = document.createElement("div");
    modal.className = "lab-modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");

    const header = document.createElement("div");
    header.className = "lab-modal-header";

    const heading = document.createElement("h2");
    heading.textContent = title;

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "×";
    closeButton.setAttribute("aria-label", "Close dialog");

    const body = document.createElement("div");
    body.className = "lab-modal-body";

    if (content instanceof HTMLElement) {
        body.appendChild(content);
    } else {
        body.textContent = String(content);
    }

    header.append(heading, closeButton);
    modal.append(header, body);
    overlay.appendChild(modal);

    function close() {
        overlay.remove();
    }

    closeButton.addEventListener("click", close);

    overlay.addEventListener("click", event => {
        if (event.target === overlay) close();
    });

    document.addEventListener("keydown", handleEscape);

    function handleEscape(event) {
        if (event.key === "Escape" && overlay.isConnected) {
            close();
        }
    }

    return {
        element: overlay,
        open(parent = document.body) {
            parent.appendChild(overlay);
        },
        close
    };
}