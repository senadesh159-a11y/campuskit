import {
    openDatabase,
    getAllData
} from "../database/database.js";

const SYNC_STORES = [
    "experiments",
    "observations",
    "lab-notebooks",
    "settings"
];

export function createSyncManager({
    firestore,
    userId
}) {
    if (!firestore || !userId) {
        throw new Error("Firebase Firestore and user ID are required.");
    }

    let isSyncing = false;

    async function uploadStore(storeName) {
        const records = await getAllData(storeName);

        for (const record of records) {
            const documentId = `${userId}_${record.id}`;

            await firestore
                .collection("virtualLab")
                .doc(userId)
                .collection(storeName)
                .doc(documentId)
                .set({
                    ...record,
                    syncedAt: new Date().toISOString()
                }, { merge: true });
        }
    }

    async function syncAll() {
        if (isSyncing) {
            throw new Error("A sync operation is already running.");
        }

        isSyncing = true;

        try {
            await openDatabase();

            for (const storeName of SYNC_STORES) {
                await uploadStore(storeName);
            }

            return {
                success: true,
                syncedAt: new Date().toISOString()
            };
        } finally {
            isSyncing = false;
        }
    }

    return {
        syncAll,

        getSyncStatus() {
            return {
                isSyncing
            };
        }
    };
}