const DATABASE_NAME = "CampusKitVirtualLab";
const DATABASE_VERSION = 1;

const STORES = [
    "experiments",
    "observations",
    "lab-notebooks",
    "settings"
];

let databasePromise = null;

export function openDatabase() {
    if (databasePromise) return databasePromise;

    databasePromise = new Promise((resolve, reject) => {
        const request = indexedDB.open(
            DATABASE_NAME,
            DATABASE_VERSION
        );

        request.onupgradeneeded = () => {
            const db = request.result;

            STORES.forEach(storeName => {
                if (!db.objectStoreNames.contains(storeName)) {
                    db.createObjectStore(storeName, {
                        keyPath: "id"
                    });
                }
            });
        };

        request.onsuccess = () => resolve(request.result);

        request.onerror = () => {
            databasePromise = null;
            reject(request.error);
        };

        request.onblocked = () => {
            reject(new Error("Database upgrade is blocked."));
        };
    });

    return databasePromise;
}

export async function saveData(storeName, data) {
    if (!STORES.includes(storeName)) {
        throw new Error("Unknown database store.");
    }

    if (!data || !data.id) {
        throw new Error("Data must contain an ID.");
    }

    const db = await openDatabase();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, "readwrite");

        transaction.objectStore(storeName).put(data);

        transaction.oncomplete = () => resolve(data);
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error);
    });
}

export async function getData(storeName, id) {
    if (!STORES.includes(storeName)) {
        throw new Error("Unknown database store.");
    }

    const db = await openDatabase();

    return new Promise((resolve, reject) => {
        const request = db
            .transaction(storeName, "readonly")
            .objectStore(storeName)
            .get(id);

        request.onsuccess = () => resolve(request.result ?? null);
        request.onerror = () => reject(request.error);
    });
}

export async function getAllData(storeName) {
    if (!STORES.includes(storeName)) {
        throw new Error("Unknown database store.");
    }

    const db = await openDatabase();

    return new Promise((resolve, reject) => {
        const request = db
            .transaction(storeName, "readonly")
            .objectStore(storeName)
            .getAll();

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

export async function deleteData(storeName, id) {
    if (!STORES.includes(storeName)) {
        throw new Error("Unknown database store.");
    }

    const db = await openDatabase();

    return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, "readwrite");

        transaction.objectStore(storeName).delete(id);

        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error);
    });
}