export const Validation = {
    isNumber(value) {
        return typeof value === "number" && Number.isFinite(value);
    },

    isPositive(value) {
        return this.isNumber(value) && value > 0;
    },

    isNonNegative(value) {
        return this.isNumber(value) && value >= 0;
    },

    isWithinRange(value, minimum, maximum) {
        return (
            this.isNumber(value) &&
            value >= minimum &&
            value <= maximum
        );
    },

    isNonEmptyString(value) {
        return typeof value === "string" && value.trim().length > 0;
    },

    isValidArray(values) {
        return Array.isArray(values) && values.length > 0;
    },

    requirePositive(value, fieldName = "Value") {
        if (!this.isPositive(value)) {
            throw new Error(`${fieldName} must be a positive number.`);
        }

        return value;
    },

    requireNonNegative(value, fieldName = "Value") {
        if (!this.isNonNegative(value)) {
            throw new Error(`${fieldName} cannot be negative.`);
        }

        return value;
    }
};