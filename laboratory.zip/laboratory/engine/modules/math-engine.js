export const MathEngine = {
    // Basic arithmetic
    add(a, b) {
        return a + b;
    },

    subtract(a, b) {
        return a - b;
    },

    multiply(a, b) {
        return a * b;
    },

    divide(a, b) {
        if (b === 0) {
            throw new Error("Division by zero is not allowed.");
        }

        return a / b;
    },

    // Square root
    squareRoot(value) {
        if (value < 0) {
            throw new Error("Cannot calculate real square root of a negative number.");
        }

        return Math.sqrt(value);
    },

    // Percentage
    percentage(value, total) {
        if (total === 0) {
            throw new Error("Total cannot be zero.");
        }

        return (value / total) * 100;
    },

    // Average
    average(values) {
        if (!Array.isArray(values) || values.length === 0) {
            throw new Error("Provide at least one numeric value.");
        }

        if (!values.every(Number.isFinite)) {
            throw new Error("All values must be finite numbers.");
        }

        return values.reduce((sum, value) => sum + value, 0)
            / values.length;
    },

    // Standard deviation (population)
    standardDeviation(values) {
        const mean = this.average(values);

        const variance = values.reduce(
            (sum, value) => sum + (value - mean) ** 2,
            0
        ) / values.length;

        return Math.sqrt(variance);
    },

    // Round a number
    round(value, decimalPlaces = 2) {
        const factor = 10 ** decimalPlaces;

        return Math.round((value + Number.EPSILON) * factor) / factor;
    },

    // Convert degrees to radians
    degreesToRadians(degrees) {
        return degrees * (Math.PI / 180);
    },

    // Convert radians to degrees
    radiansToDegrees(radians) {
        return radians * (180 / Math.PI);
    }
};