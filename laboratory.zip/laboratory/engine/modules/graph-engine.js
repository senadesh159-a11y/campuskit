export const GraphEngine = {
    // Prepare observation data for plotting
    prepareData(readings, xKey, yKey) {
        if (!Array.isArray(readings)) {
            throw new Error("Readings must be an array.");
        }

        return readings.map((reading, index) => {
            const x = Number(reading[xKey]);
            const y = Number(reading[yKey]);

            if (!Number.isFinite(x) || !Number.isFinite(y)) {
                throw new Error(
                    `Invalid graph data at reading ${index + 1}.`
                );
            }

            return { x, y };
        });
    },

    // Calculate linear regression
    linearRegression(points) {
        if (!Array.isArray(points) || points.length < 2) {
            throw new Error("At least two points are required.");
        }

        const n = points.length;

        const meanX = points.reduce((sum, p) => sum + p.x, 0) / n;
        const meanY = points.reduce((sum, p) => sum + p.y, 0) / n;

        const numerator = points.reduce(
            (sum, p) => sum + (p.x - meanX) * (p.y - meanY),
            0
        );

        const denominator = points.reduce(
            (sum, p) => sum + (p.x - meanX) ** 2,
            0
        );

        if (denominator === 0) {
            throw new Error("Cannot calculate regression for identical X values.");
        }

        const slope = numerator / denominator;
        const intercept = meanY - slope * meanX;

        return {
            slope,
            intercept,
            equation: `y = ${slope.toFixed(4)}x + ${intercept.toFixed(4)}`
        };
    },

    // Calculate coefficient of determination (R²)
    calculateRSquared(points, regression) {
        if (!Array.isArray(points) || points.length < 2) {
            throw new Error("At least two points are required.");
        }

        const meanY = points.reduce((sum, p) => sum + p.y, 0)
            / points.length;

        const totalVariation = points.reduce(
            (sum, p) => sum + (p.y - meanY) ** 2,
            0
        );

        const residualVariation = points.reduce((sum, p) => {
            const predicted = regression.slope * p.x + regression.intercept;
            return sum + (p.y - predicted) ** 2;
        }, 0);

        if (totalVariation === 0) {
            throw new Error("R² is undefined when all Y values are identical.");
        }

        return 1 - residualVariation / totalVariation;
    }
};