const UnitConverter = {
    // Length
    metersToCentimeters(value) {
        return value * 100;
    },

    centimetersToMeters(value) {
        return value / 100;
    },

    metersToKilometers(value) {
        return value / 1000;
    },

    // Mass
    kilogramsToGrams(value) {
        return value * 1000;
    },

    gramsToKilograms(value) {
        return value / 1000;
    },

    // Time
    minutesToSeconds(value) {
        return value * 60;
    },

    hoursToSeconds(value) {
        return value * 3600;
    },

    // Temperature
    celsiusToKelvin(value) {
        return value + 273.15;
    },

    kelvinToCelsius(value) {
        return value - 273.15;
    },

    celsiusToFahrenheit(value) {
        return (value * 9 / 5) + 32;
    },

    fahrenheitToCelsius(value) {
        return (value - 32) * 5 / 9;
    },

    // Pressure
    pascalToKilopascal(value) {
        return value / 1000;
    },

    kilopascalToPascal(value) {
        return value * 1000;
    },

    // Volume
    litersToMilliliters(value) {
        return value * 1000;
    },

    millilitersToLiters(value) {
        return value / 1000;
    }
};

export { UnitConverter };