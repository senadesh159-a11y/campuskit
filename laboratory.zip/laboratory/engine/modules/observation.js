const observationRecords = new Map();

export const Observation = {
    // Create a new observation record
    create(experimentId, title = "Experiment Observations") {
        if (!experimentId) {
            throw new Error("Experiment ID is required.");
        }

        const id = crypto.randomUUID();

        const record = {
            id,
            experimentId,
            title,
            readings: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        observationRecords.set(id, record);

        return record;
    },

    // Add a reading
    addReading(recordId, reading) {
        const record = observationRecords.get(recordId);

        if (!record) {
            throw new Error("Observation record not found.");
        }

        if (!reading || typeof reading !== "object") {
            throw new Error("Invalid reading.");
        }

        record.readings.push({
            ...reading,
            recordedAt: new Date().toISOString()
        });

        record.updatedAt = new Date().toISOString();

        return record;
    },

    // Get one observation record
    get(recordId) {
        return observationRecords.get(recordId) || null;
    },

    // Get all records for an experiment
    getByExperiment(experimentId) {
        return Array.from(observationRecords.values()).filter(
            record => record.experimentId === experimentId
        );
    },

    // Delete an observation record
    delete(recordId) {
        return observationRecords.delete(recordId);
    },

    // Export observations as JSON
    exportJSON(recordId) {
        const record = this.get(recordId);

        if (!record) {
            throw new Error("Observation record not found.");
        }

        return JSON.stringify(record, null, 2);
    }
};