const GRAVITY = 9.80665;

export const PhysicsEngine = {
    gravity: GRAVITY,

    // Calculate acceleration using Newton's second law
    calculateAcceleration(force, mass) {
        if (mass <= 0) {
            throw new Error("Mass must be greater than zero.");
        }

        return force / mass;
    },

    // Calculate weight
    calculateWeight(mass) {
        if (mass < 0) {
            throw new Error("Mass cannot be negative.");
        }

        return mass * GRAVITY;
    },

    // Calculate velocity
    calculateVelocity(initialVelocity, acceleration, time) {
        return initialVelocity + acceleration * time;
    },

    // Calculate displacement
    calculateDisplacement(initialVelocity, acceleration, time) {
        return (
            initialVelocity * time +
            0.5 * acceleration * time * time
        );
    },

    // Calculate simple pendulum time period
    calculatePendulumPeriod(length) {
        if (length <= 0) {
            throw new Error("Pendulum length must be positive.");
        }

        return 2 * Math.PI * Math.sqrt(length / GRAVITY);
    },

    // Calculate spring force using Hooke's law
    calculateSpringForce(springConstant, displacement) {
        if (springConstant < 0) {
            throw new Error("Spring constant cannot be negative.");
        }

        return -springConstant * displacement;
    },

    // Calculate kinetic energy
    calculateKineticEnergy(mass, velocity) {
        if (mass < 0) {
            throw new Error("Mass cannot be negative.");
        }

        return 0.5 * mass * velocity * velocity;
    },

    // Calculate gravitational potential energy
    calculatePotentialEnergy(mass, height) {
        if (mass < 0) {
            throw new Error("Mass cannot be negative.");
        }

        return mass * GRAVITY * height;
    }
};