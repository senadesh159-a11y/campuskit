export const FormulaLibrary = {
    physics: {
        mechanics: {
            newtonsSecondLaw: {
                name: "Newton's Second Law",
                formula: "F = ma",
                description: "Force equals mass multiplied by acceleration.",
                unit: "N"
            },

            weight: {
                name: "Weight",
                formula: "W = mg",
                description: "Weight equals mass multiplied by gravitational acceleration.",
                unit: "N"
            },

            kineticEnergy: {
                name: "Kinetic Energy",
                formula: "KE = 1/2 mv²",
                description: "Energy possessed by a moving body.",
                unit: "J"
            },

            potentialEnergy: {
                name: "Gravitational Potential Energy",
                formula: "PE = mgh",
                description: "Energy due to height in a gravitational field.",
                unit: "J"
            }
        },

        oscillations: {
            simplePendulum: {
                name: "Simple Pendulum Time Period",
                formula: "T = 2π√(L/g)",
                description: "Time period for small angular oscillations.",
                unit: "s",
                condition: "Small oscillation angle"
            }
        },

        elasticity: {
            youngModulus: {
                name: "Young's Modulus",
                formula: "Y = (F/A)/(ΔL/L)",
                description: "Ratio of longitudinal stress to longitudinal strain.",
                unit: "Pa"
            }
        }
    },

    chemistry: {
        solutions: {
            molarity: {
                name: "Molarity",
                formula: "M = n/V",
                description: "Moles of solute per litre of solution.",
                unit: "mol/L"
            },

            dilution: {
                name: "Dilution Equation",
                formula: "M₁V₁ = M₂V₂",
                description: "Concentration-volume relationship during dilution.",
                unit: "mol/L and L"
            }
        },

        acidsAndBases: {
            ph: {
                name: "pH",
                formula: "pH = -log₁₀[H⁺]",
                description: "Negative logarithm of hydrogen ion activity; concentration is an approximation in dilute solutions.",
                unit: "dimensionless"
            }
        }
    }
};