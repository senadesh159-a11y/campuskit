const experiments = new Map();

export const ExperimentData = {
    // Register a new experiment
    register(experiment) {
        if (!experiment || typeof experiment !== "object") {
            throw new Error("Invalid experiment data.");
        }

        const { id, name, subject, level } = experiment;

        if (!id || !name || !subject || !level) {
            throw new Error(
                "Experiment requires id, name, subject and level."
            );
        }

        if (experiments.has(id)) {
            throw new Error(`Experiment already exists: ${id}`);
        }

        experiments.set(id, {
            ...experiment,
            registeredAt: new Date().toISOString()
        });

        return experiments.get(id);
    },

    // Find an experiment by ID
    get(id) {
        return experiments.get(id) || null;
    },

    // Get all registered experiments
    getAll() {
        return Array.from(experiments.values());
    },

    // Filter experiments by subject
    getBySubject(subject) {
        return this.getAll().filter(
            experiment => experiment.subject === subject
        );
    },

    // Filter experiments by education level
    getByLevel(level) {
        return this.getAll().filter(
            experiment => experiment.level === level
        );
    },

    // Check whether an experiment exists
    exists(id) {
        return experiments.has(id);
    },

    // Remove an experiment
    remove(id) {
        return experiments.delete(id);
    },

    // Clear the registry
    clear() {
        experiments.clear();
    }
};