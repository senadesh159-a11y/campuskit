import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

export const RenderUtils = {
    // Create a standard 3D material
    createMaterial(color = 0xffffff, options = {}) {
        return new THREE.MeshStandardMaterial({
            color,
            roughness: options.roughness ?? 0.5,
            metalness: options.metalness ?? 0.1,
            transparent: options.transparent ?? false,
            opacity: options.opacity ?? 1
        });
    },

    // Create a box
    createBox(width, height, depth, material) {
        const geometry = new THREE.BoxGeometry(width, height, depth);
        return new THREE.Mesh(geometry, material);
    },

    // Create a cylinder
    createCylinder(radiusTop, radiusBottom, height, material) {
        const geometry = new THREE.CylinderGeometry(
            radiusTop,
            radiusBottom,
            height,
            32
        );

        return new THREE.Mesh(geometry, material);
    },

    // Create a sphere
    createSphere(radius, material) {
        const geometry = new THREE.SphereGeometry(radius, 32, 24);
        return new THREE.Mesh(geometry, material);
    },

    // Add shadows
    enableShadows(object) {
        object.castShadow = true;
        object.receiveShadow = true;

        return object;
    },

    // Dispose geometry and materials
    disposeObject(object) {
        if (!object) return;

        object.traverse(child => {
            if (!child.isMesh) return;

            child.geometry?.dispose();

            if (Array.isArray(child.material)) {
                child.material.forEach(material => material.dispose());
            } else {
                child.material?.dispose();
            }
        });

        object.removeFromParent();
    }
};