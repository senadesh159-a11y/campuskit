export function createLabAudio() {
    let audioContext = null;
    let isEnabled = true;

    function getAudioContext() {
        if (!audioContext) {
            const AudioContextClass =
                window.AudioContext || window.webkitAudioContext;

            if (!AudioContextClass) {
                throw new Error("Audio is not supported in this browser.");
            }

            audioContext = new AudioContextClass();
        }

        if (audioContext.state === "suspended") {
            audioContext.resume();
        }

        return audioContext;
    }

    function playTone(frequency = 440, duration = 0.15) {
        if (!isEnabled) return;

        const context = getAudioContext();
        const oscillator = context.createOscillator();
        const gain = context.createGain();

        oscillator.type = "sine";
        oscillator.frequency.value = frequency;

        gain.gain.setValueAtTime(0.08, context.currentTime);
        gain.gain.exponentialRampToValueAtTime(
            0.001,
            context.currentTime + duration
        );

        oscillator.connect(gain);
        gain.connect(context.destination);

        oscillator.start();
        oscillator.stop(context.currentTime + duration);
    }

    return {
        playClick() {
            playTone(650, 0.08);
        },

        playSuccess() {
            playTone(880, 0.18);
        },

        playError() {
            playTone(220, 0.25);
        },

        setEnabled(value) {
            isEnabled = Boolean(value);
        },

        async dispose() {
            if (audioContext) {
                await audioContext.close();
                audioContext = null;
            }
        }
    };
}