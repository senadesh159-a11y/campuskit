import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

const HIGHLIGHT_COLOR = 0x9cff00;

export function createEquipment({
    name = "Laboratory Equipment",
    color = 0x8fa3b8,
    size = [1, 1, 1],
    position = [0, 0.5, 0]
} = {}) {
    const geometry = new THREE.BoxGeometry(
        size[0],
        size[1],
        size[2]
    );

    const material = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.4,
        metalness: 0.25
    });

    const equipment = new THREE.Mesh(geometry, material);

    equipment.name = name;
    equipment.position.set(...position);

    equipment.castShadow = true;
    equipment.receiveShadow = true;

    equipment.userData = {
        selectable: true,
        equipmentName: name,
        originalColor: color,
        size: [...size],
        originalPosition: [...position],
        originalRotation: [0, 0, 0],
        highlighted: false
    };

    return equipment;
}

export function setEquipmentSelected(equipment, selected) {
    if (!equipment?.isMesh) return;

    const materials = Array.isArray(equipment.material)
        ? equipment.material
        : [equipment.material];

    if (selected && !equipment.userData.highlighted) {
        materials.forEach(material => {
            if (!material?.color) return;

            material.userData.originalColor = material.color.getHex();

            material.color.setHex(HIGHLIGHT_COLOR);

            if (material.emissive) {
                material.emissive.setHex(HIGHLIGHT_COLOR);
                material.emissiveIntensity = 0.25;
            }
        });

        equipment.userData.highlighted = true;

    } else if (!selected && equipment.userData.highlighted) {
        materials.forEach(material => {
            if (!material?.color) return;

            material.color.setHex(
                material.userData.originalColor ??
                equipment.userData.originalColor
            );

            if (material.emissive) {
                material.emissive.setHex(0x000000);
                material.emissiveIntensity = 0;
            }
        });

        equipment.userData.highlighted = false;
    }
}

export function duplicateEquipment(equipment) {
    if (!equipment?.isMesh) return null;

    const copy = createEquipment({
        name: `${equipment.userData.equipmentName} Copy`,
        color: equipment.userData.originalColor,
        size: equipment.userData.size,
        position: [
            equipment.position.x + 1.5,
            equipment.position.y,
            equipment.position.z
        ]
    });

    copy.rotation.copy(equipment.rotation);

    return copy;
}

export function resetEquipment(equipment) {
    if (!equipment?.isMesh) return;

    const originalPosition = equipment.userData.originalPosition;
    const originalRotation = equipment.userData.originalRotation;

    equipment.position.set(...originalPosition);
    equipment.rotation.set(...originalRotation);
}

export function disposeEquipment(equipment) {
    if (!equipment) return;

    equipment.geometry?.dispose();

    if (Array.isArray(equipment.material)) {
        equipment.material.forEach(material => material.dispose());
    } else {
        equipment.material?.dispose();
    }

    equipment.removeFromParent();
}