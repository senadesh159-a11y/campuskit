import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

export function createLabEnvironment(scene) {
    if (!scene) {
        throw new Error("Scene not found.");
    }

    // Laboratory walls
    const wallMaterial = new THREE.MeshStandardMaterial({
        color: 0x303b46,
        roughness: 0.85
    });

    const backWall = new THREE.Mesh(
        new THREE.BoxGeometry(40, 10, 0.3),
        wallMaterial
    );

    backWall.position.set(0, 5, -10);
    backWall.receiveShadow = true;
    scene.add(backWall);

    // Laboratory workbench
    const tableMaterial = new THREE.MeshStandardMaterial({
        color: 0x626d78,
        roughness: 0.55
    });

    const table = new THREE.Mesh(
        new THREE.BoxGeometry(8, 0.25, 4),
        tableMaterial
    );

    table.position.set(0, 1.2, 0);
    table.castShadow = true;
    table.receiveShadow = true;
    scene.add(table);

    // Table legs
    const legGeometry = new THREE.BoxGeometry(0.2, 1.2, 0.2);
    const legs = [];

    const positions = [
        [-3.7, 0.6, -1.7],
        [3.7, 0.6, -1.7],
        [-3.7, 0.6, 1.7],
        [3.7, 0.6, 1.7]
    ];

    positions.forEach(position => {
        const leg = new THREE.Mesh(legGeometry, tableMaterial);
        leg.position.set(...position);
        leg.castShadow = true;

        scene.add(leg);
        legs.push(leg);
    });

    return {
        backWall,
        table,
        legs,

        dispose() {
            scene.remove(backWall);
            scene.remove(table);

            legs.forEach(leg => scene.remove(leg));

            backWall.geometry.dispose();
            table.geometry.dispose();
            legGeometry.dispose();

            wallMaterial.dispose();
            tableMaterial.dispose();
        }
    };
}