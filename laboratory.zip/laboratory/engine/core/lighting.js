import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

export function createLighting(scene) {
    if (!scene) {
        throw new Error("Scene not found.");
    }

    // Soft laboratory ambient light
    const ambientLight = new THREE.HemisphereLight(
        0xffffff,
        0x667080,
        2
    );

    scene.add(ambientLight);

    // Main laboratory light
    const mainLight = new THREE.DirectionalLight(
        0xffffff,
        3
    );

    mainLight.position.set(5, 8, 6);
    mainLight.castShadow = true;

    mainLight.shadow.mapSize.set(2048, 2048);
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 50;

    scene.add(mainLight);

    // Soft fill light
    const fillLight = new THREE.DirectionalLight(
        0xdceaff,
        1
    );

    fillLight.position.set(-5, 3, -4);
    scene.add(fillLight);

    // Laboratory environment light
    const backLight = new THREE.PointLight(
        0xffffff,
        30,
        25
    );

    backLight.position.set(0, 5, -5);
    scene.add(backLight);

    return {
        ambientLight,
        mainLight,
        fillLight,
        backLight,

        dispose() {
            scene.remove(ambientLight);
            scene.remove(mainLight);
            scene.remove(fillLight);
            scene.remove(backLight);

            ambientLight.dispose?.();
            mainLight.dispose?.();
            fillLight.dispose?.();
            backLight.dispose?.();
        }
    };
}