import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

import { createLighting } from "./lighting.js";

export function createLabScene() {
    const scene = new THREE.Scene();

    // Laboratory background
    scene.background = new THREE.Color(0x101820);

    // Atmospheric depth
    scene.fog = new THREE.Fog(
        0x101820,
        15,
        45
    );

    // Laboratory lighting
    const lighting = createLighting(scene);

    // Main laboratory floor
    const floorGeometry = new THREE.PlaneGeometry(40, 40);

    const floorMaterial = new THREE.MeshStandardMaterial({
        color: 0x252d35,
        roughness: 0.75,
        metalness: 0.15
    });

    const floor = new THREE.Mesh(
        floorGeometry,
        floorMaterial
    );

    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.01;
    floor.receiveShadow = true;

    scene.add(floor);

    // Reference grid
    const grid = new THREE.GridHelper(
        40,
        40,
        0x647080,
        0x3c4652
    );

    grid.position.y = 0.005;
    scene.add(grid);

    return {
        scene,
        lighting,
        floor,
        grid,

        dispose() {
            scene.remove(floor);
            scene.remove(grid);

            floor.geometry.dispose();
            floor.material.dispose();

            grid.geometry.dispose();
            grid.material.dispose();

            lighting.dispose();
        }
    };
}