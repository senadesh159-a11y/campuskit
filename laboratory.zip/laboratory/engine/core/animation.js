export function createAnimationLoop(renderer, scene, camera) {
    if (!renderer || !scene || !camera) {
        throw new Error("Animation setup is incomplete.");
    }

    let animationFrameId = null;
    let isRunning = false;
    let lastFrameTime = 0;

    const callbacks = new Set();

    function animate(currentTime) {
        if (!isRunning) return;

        const deltaTime = lastFrameTime
            ? Math.min((currentTime - lastFrameTime) / 1000, 0.05)
            : 0;

        lastFrameTime = currentTime;

        callbacks.forEach(callback => {
            callback(deltaTime, currentTime);
        });

        renderer.render(scene, camera);

        animationFrameId = requestAnimationFrame(animate);
    }

    function start() {
        if (isRunning) return;

        isRunning = true;
        lastFrameTime = 0;

        animationFrameId = requestAnimationFrame(animate);
    }

    function stop() {
        isRunning = false;

        if (animationFrameId !== null) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
    }

    function addUpdate(callback) {
        if (typeof callback !== "function") {
            throw new Error("Update must be a function.");
        }

        callbacks.add(callback);

        return () => callbacks.delete(callback);
    }

    return {
        start,
        stop,
        addUpdate,

        dispose() {
            stop();
            callbacks.clear();
        }
    };
}