import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";

import {
    setEquipmentSelected,
    disposeEquipment
} from "./equipment.js";

export function createInteractionManager(
    rendererElement,
    camera,
    scene
) {
    if (!rendererElement || !camera || !scene) {
        throw new Error("Interaction setup is incomplete.");
    }

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const dragPlane = new THREE.Plane(
        new THREE.Vector3(0, 1, 0),
        0
    );

    const intersection = new THREE.Vector3();
    const dragOffset = new THREE.Vector3();

    let selectedObject = null;
    let draggedObject = null;
    let isDragging = false;

    function updatePointer(event) {
        const rect = rendererElement.getBoundingClientRect();

        pointer.x =
            ((event.clientX - rect.left) / rect.width) * 2 - 1;

        pointer.y =
            -((event.clientY - rect.top) / rect.height) * 2 + 1;
    }

    function getSelectableHit(event) {
        updatePointer(event);
        raycaster.setFromCamera(pointer, camera);

        const objects = [];

        scene.traverse(object => {
            if (object.isMesh && object.userData.selectable) {
                objects.push(object);
            }
        });

        const hits = raycaster.intersectObjects(objects, true);

        if (!hits.length) return null;

        let object = hits[0].object;

        while (object && !object.userData.selectable) {
            object = object.parent;
        }

        return object || null;
    }

    function emitEvent(eventName, object) {
        rendererElement.dispatchEvent(
            new CustomEvent(eventName, {
                detail: { object }
            })
        );
    }

    function selectObject(object) {
        if (selectedObject === object) return;

        if (selectedObject) {
            setEquipmentSelected(selectedObject, false);
        }

        selectedObject = object;

        if (selectedObject) {
            setEquipmentSelected(selectedObject, true);
        }

        emitEvent("lab-object-selected", selectedObject);
    }

    function handlePointerDown(event) {
        if (event.button !== 0) return;

        const object = getSelectableHit(event);

        if (!object) {
            selectObject(null);
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();

        selectObject(object);

        draggedObject = object;

        dragPlane.constant = -object.position.y;

        raycaster.setFromCamera(pointer, camera);

        if (raycaster.ray.intersectPlane(dragPlane, intersection)) {
            dragOffset.copy(intersection).sub(object.position);
        }

        isDragging = true;

        rendererElement.style.cursor = "grabbing";

        rendererElement.setPointerCapture?.(event.pointerId);
    }

    function handlePointerMove(event) {
        if (!isDragging || !draggedObject) {
            rendererElement.style.cursor = "grab";
            return;
        }

        updatePointer(event);
        raycaster.setFromCamera(pointer, camera);

        if (raycaster.ray.intersectPlane(dragPlane, intersection)) {
            draggedObject.position.x =
                intersection.x - dragOffset.x;

            draggedObject.position.z =
                intersection.z - dragOffset.z;

            emitEvent("lab-object-moved", draggedObject);
        }
    }

    function handlePointerUp(event) {
        if (!isDragging) return;

        isDragging = false;
        draggedObject = null;

        rendererElement.style.cursor = "grab";

        if (rendererElement.hasPointerCapture?.(event.pointerId)) {
            rendererElement.releasePointerCapture(event.pointerId);
        }
    }

    function handlePointerCancel() {
        isDragging = false;
        draggedObject = null;
        rendererElement.style.cursor = "grab";
    }

    function addEquipment(equipment) {
        if (!equipment) return;

        scene.add(equipment);
        emitEvent("lab-equipment-added", equipment);
    }

    function deleteSelected() {
        if (!selectedObject) return false;

        const object = selectedObject;

        selectObject(null);
        disposeEquipment(object);

        emitEvent("lab-equipment-deleted", object);

        return true;
    }

    function rotateSelected(axis = "y", angle = Math.PI / 4) {
        if (!selectedObject) return false;

        if (!["x", "y", "z"].includes(axis)) return false;

        selectedObject.rotation[axis] += angle;

        emitEvent("lab-object-moved", selectedObject);

        return true;
    }

    function resetSelected() {
        if (!selectedObject) return false;

        const object = selectedObject;

        object.position.set(
            ...object.userData.originalPosition
        );

        object.rotation.set(
            ...object.userData.originalRotation
        );

        emitEvent("lab-object-moved", object);

        return true;
    }

    function getSelectedObject() {
        return selectedObject;
    }

    rendererElement.style.cursor = "grab";

    rendererElement.addEventListener(
        "pointerdown",
        handlePointerDown,
        true
    );

    rendererElement.addEventListener(
        "pointermove",
        handlePointerMove
    );

    rendererElement.addEventListener(
        "pointerup",
        handlePointerUp
    );

    rendererElement.addEventListener(
        "pointercancel",
        handlePointerCancel
    );

    return {
        addEquipment,
        deleteSelected,
        rotateSelected,
        resetSelected,
        selectObject,
        getSelectedObject,

        dispose() {
            rendererElement.removeEventListener(
                "pointerdown",
                handlePointerDown,
                true
            );

            rendererElement.removeEventListener(
                "pointermove",
                handlePointerMove
            );

            rendererElement.removeEventListener(
                "pointerup",
                handlePointerUp
            );

            rendererElement.removeEventListener(
                "pointercancel",
                handlePointerCancel
            );

            if (selectedObject) {
                setEquipmentSelected(selectedObject, false);
            }

            rendererElement.style.cursor = "default";

            selectedObject = null;
            draggedObject = null;
            isDragging = false;
        }
    };
}